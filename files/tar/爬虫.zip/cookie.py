import time

from selenium import webdriver
class C:
    @staticmethod
    def get_cookie(url):
        driver = webdriver.Edge()
        with open('stealth.min.js', 'r', encoding='utf-8') as f:
            js = f.read()
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": js
        })
        driver.get(url)
        # 手动验证
        time.sleep(15)
        res = driver.execute_script('return document.cookie')
        return res