import csv
import hashlib
import json
import os.path
import random
import time
import js2py

import bs4
import numpy as np
import requests

from ddddocr_woff.ocrUtil import ocr


class main:
    OCR = None
    none_bs4 = bs4.BeautifulSoup('<html></html>', 'html.parser')
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.79',
        'Host': 'www.maoyan.com',
        'Pragma': 'no-cache',
        'Referer': 'https://www.maoyan.com/films/1413252',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'X-Requested-With': 'XMLHttpRequest',
        'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Microsoft Edge";v="114"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': "Windows",
        'Cookie': 'uuid_n_v=v1; uuid=0E021110215411EEB5DB33031B0079F36845EC5D886A4D478D63E4D250D08F92; _lxsdk_cuid=1894e48c978c8-0bc749d36a0a65-47716d2b-1fa400-1894e48c978c8; _lxsdk=0E021110215411EEB5DB33031B0079F36845EC5D886A4D478D63E4D250D08F92; _lx_utm=utm_source%3Dbing%26utm_medium%3Dorganic; _csrf=c3e4c90e1aee6567c91e70df7e4b2f14145284595e0d17f60235d285145b88d3; Hm_lvt_703e94591e87be68cc8da0da7cbd0be2=1689235540,1689297231,1689315901; __mta=147757960.1689235540676.1689315901362.1689315979896.54; _lxsdk_s=1895312fed2-ad5-c74-06f%7C%7C7; Hm_lpvt_703e94591e87be68cc8da0da7cbd0be2=1689317140'
    }

    def __init__(self):
        self.OCR = ocr()
        pass

    def req(self, url, params={}):
        resp = requests.get(url=url, headers=self.header, params=params)
        soup = bs4.BeautifulSoup(resp.text, 'html.parser')
        return {'response': resp, 'soup': soup}

    # 计算md5
    def get_md5(self, index, channel_id, time_stamp, s_version=1, webdriver=False,
                key='A013F70DB97834C0A5492378BD76C53A'):
        s = f'method=GET&timeStamp={time_stamp}&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.79&index={index}&channelId=40011&sVersion=1&key=A013F70DB97834C0A5492378BD76C53A'
        # s = f'method=GET&timeStamp={time_stamp}&User-Agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.79&index={index}&channelId={channel_id}&sVersion={s_version}&key={key}'
        md = hashlib.md5(s.encode('utf-8'))
        return md.hexdigest()

    # 获取所有可搜索分类
    def get_category(self):
        if os.path.exists('./cache/category.json'):
            with open('./cache/category.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        url = 'https://www.maoyan.com/films'
        soup = self.req(url)['soup']
        lis = soup.find('ul', attrs={'class': ['tags-lines']}).find_all('li', attrs={'class': ['tags-line']})
        lists = [{}, {}, {}]
        for index in range(0, 3):
            category_li = lis[index].find_all('li')
            category = lists[index]
            i = 1
            while i < len(category_li):
                category[category_li[i].text.replace('\n', '')] = category_li[i].find('a')['href']
                i += 1
        re = {
            'category': lists[0],
            'location': lists[1],
            'year': lists[2]
        }
        with open('./cache/category.json', 'w', encoding='utf-8') as f:
            json.dump(re, f)
        return re

    # 获取电影列表
    def get_film_list(self, offset=0, category: str = None, location: str = None, year: str = None):
        ca = self.get_category()
        url = 'https://www.maoyan.com/films?showType=3&sortId=3&offset=' + str(offset)  # 经典影片,热门排序
        if category is not None and ca['category'].get(category, None) is not None:
            url += '&' + ca['category'].get(category)[1:]
        if location is not None and ca['location'].get(location, None) is not None:
            url += '&' + ca['location'].get(location)[1:]
        if year is not None and ca['year'].get(year, None) is not None:
            url += '&' + ca['year'].get(year)[1:]
        soup = self.req(url)['soup']
        dd = soup.find_all('dd')
        re = []
        for d in dd:
            url = d.find('div').find('a')['href']
            id = url.split('/')[-1]
            re.append(id)
        return re

    # 获取电影详情soup
    def get_films_soup(self, id):
        url = 'https://www.maoyan.com/ajax/films/' + id
        # 随机时间戳
        time_stamp = int(time.time() * 1000)
        context = js2py.EvalJs()
        context.execute("""
        function c(){
            re = {
                index: Math['ceil'](10 * Math['random']()),
                timeStamp: (new Date)['getTime'](),
            }
            return JSON.stringify(re)
        }
        """)
        da = json.loads(context.c())
        index = da['index']
        time_stamp = da['timeStamp']
        # 参数
        params = {'timeStamp': str(time_stamp), 'index': str(index),
                  'signKey': self.get_md5(index=index, channel_id=40011, time_stamp=time_stamp),
                  'channelId': str(40011), 'sVersion': '1', 'webdriver': 'false'}
        url += "?"
        i = True
        for t in params.keys():
            if i:
                url = url + t + '=' + params[t]
                i = False
            else:
                url = url + '&' + t + '=' + params[t]
        print(url)
        # print('https://www.maoyan.com/ajax/films/1413252?timeStamp=1689313562426&index=1&signKey=0ae0fff590d726de5b2cfd0f879830b9&channelId=40011&sVersion=1&webdriver=false')
        # 返回soup
        da = self.req(url)
        soup = da['soup']
        # rep = da['response']
        # with open('test.html', 'w', encoding='utf-8') as f:
        #     f.write(rep.text)
        if len(soup.text) < 20:
            cookie = C.get_cookie('https://www.maoyan.com/films/' + id)
            self.header['Cookie'] = cookie
            soup = self.req(url)['soup']
            pass  # 获取cookie
        # print(soup)
        # print(films_name)
        return soup

    def get_real_num(self, s: str, num: dict):
        ans = ''
        s = s.encode('unicode_escape').decode('utf-8')
        i = 0
        while i < len(s):
            t = s[i:i + 6]
            if t.startswith('\\u'):
                ans = ans + str(num.get(t.replace('\\u', '&#x'), t.encode('utf-8').decode('unicode_escape')))
                i += 6
            else:
                ans = ans + s[i]
                i += 1
        return ans.strip().replace('\\n', '')

    #  获取单个电影的信息
    def get_films_info(self, id: str) -> dict:
        soup = self.get_films_soup(id)
        # 下面是电影名字
        name = soup.find('h1')
        if name is not None:
            name = name.text
        title_box = soup.find('div', attrs={'class': ['movie-brief-container']})
        info = self.none_bs4
        category = []
        if title_box is not None:
            info = title_box.find_all('li')
            t = info[0].find_all('a')
            if t is not None:
                for it in t:
                    category.append(it.text)
        else:
            pass
        where = ''
        if len(info) > 1 and info[1].text is not None:
            where = info[1].text.replace(' ', '').replace('\n', '')
        release_time = ''
        if info is not None and len(info) > 2:
            release_time = info[2].text
        # 数字
        nums = self.get_woff(soup)
        # 下面是评分等数据
        box = soup.find('div', attrs={'class': ['movie-index']})
        score_div = self.none_bs4
        if box is not None:
            t = box.find_all('div', attrs={'class': ['movie-index-content']})
            if t is not None:
                score_div = t[0]
        t = score_div.find_all('span')
        score = ''
        if t is not None and len(t) > 1:
            score = self.get_real_num(t[1].text, nums)  # 评分
        t = score_div.find_all('span', attrs={'class': ['stonefont']})
        score_num = ''
        if t is not None and len(t) > 1:
            score_num = self.get_real_num(t[1].text, nums)  # 评分人数
        t = soup.find_all('div', attrs={'class': ['movie-index']})
        box2 = None
        if t is not None and len(t) > 1:
            box2 = t[1].find_all('span')
        box_office = ''
        box_office_unit = ''
        if box2 is not None and len(box2) > 1:
            box_office = self.get_real_num(box2[0].text, nums)  # 票房
            box_office_unit = box2[1].text  # 票房单位
        # 首周票房
        first_week = soup.find('div', attrs={'class': ['film-mbox']})
        if first_week is not None:
            first_week = first_week.find_all('div', attrs={'class': ['film-mbox-item']})
        if first_week is not None and len(first_week) > 0:
            first_week = first_week[0].find_all('div')
        first_week_office = ''
        first_week_office_unit = ''
        if first_week is not None and len(first_week) > 1:
            first_week_office = first_week[0].text
            first_week_office_unit = first_week[1].text.replace('首周票房(', '').replace(')', '')
        return {
            'id': str(id),
            'name': name, 'category': str(category), 'where': where, 'release_time': release_time, 'score': score,
            'score_num': score_num, 'office': box_office, 'office_unit': box_office_unit,
            'first_week_office': first_week_office, 'first_week_office_unit': first_week_office_unit
        }

    # 获取字体映射信息
    def get_woff(self, soup: bs4.BeautifulSoup):
        style = soup.find('style')
        text = style.text
        start = text.rfind('//')
        end = text.rfind('.woff')
        woff = "https:" + text[start:end + 5]
        return self.OCR.get(woff)

    def handle_one_year(self, year: str, category: str = None, location: str = None, max_: int = 99999990):
        history = {
            'offset': 0,
        }
        if not os.path.exists("./cache/data/cache"):
            os.makedirs("./cache/data/cache")
        # 存放数据的文件夹
        if os.path.exists('./cache/data/cache/data' + str(year) + '.json'):
            with open('./cache/data/cache/data' + str(year) + '.json', 'r', encoding='utf-8') as f:
                history = json.load(f)
        if not os.path.exists('./cache/data/data_' + str(year) + '.csv'):
            with open('./cache/data/data_' + str(year) + '.csv', "w") as f:
                csv_w = csv.writer(f)
                csv_w.writerow(
                    ['id', '名称', '分类', '上映地点', '上映时间', '评分', '评分人数', '首周票房', '首周票房单位',
                     '总票房', "总票房单位"])
        offset = history['offset']
        li = [0]
        while len(li) > 0 and offset < max_:
            print("[", str(year), "]正在爬取第", str(offset), "条开始的n条数据,[max]:", max_)
            data_list = []
            li = self.get_film_list(offset=offset, year=year, category=category, location=location)
            for item in li:
                data = self.get_films_info(item)
                data_list.append(data)
            #  存储数据
            with open('./cache/data/data_' + str(year) + '.csv', "a+") as f:
                csv_w = csv.writer(f)
                for it in data_list:
                    csv_w.writerow([
                        it.get('id', ''),
                        it.get('name', ''),
                        it.get('category', ''),
                        it.get('where', ''),
                        it.get('release_time', ''),
                        it.get('score', ''),
                        it.get('score_num', ''),
                        it.get('first_week_office', ''),
                        it.get('first_week_office_unit', ''),
                        it.get('office', ''),
                        it.get('office_unit', ''),
                    ])
            offset = offset + len(li)
            history['offset'] = history['offset'] + len(li)
            with open('./cache/data/cache/data' + str(year) + '.json', 'w', encoding='utf-8') as f:
                json.dump(history, f, ensure_ascii=False)

    def run(self):
        max_list = [1600, 300, 330, 300, 420, 420, 400, 380, 310, 110, 150, 180, 1200, 1200, 1200, 1200]
        for i in range(2011, 2023):
            self.handle_one_year(str(i), max_=max_list[i - 2011])
        pass


from cookie import C

if __name__ == '__main__':
    main = main()
    main.run()
    pass
