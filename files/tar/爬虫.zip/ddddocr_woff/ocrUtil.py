import json
import uuid
import uuid
import os
import requests
import re

from fontTools.ttLib import TTFont, TTLibError
from ddddocr_woff import woff_ocr
import hashlib


# todo: 禁用控制台输出


class WoffFontOcrFaFa:
    """
    xml 中：<map code="0xed98" name="uniED98"/><!-- ???? -->
    ocr 结果 中 {'uniED98.png': '9'}
    """

    def __init__(self, font_utl: str, uuid: str):
        self.font_url = font_utl
        self.file_name = uuid

        if not os.path.exists('cache'):
            print('缓存文件夹不存在，新建缓存文件夹')
            os.makedirs('cache')

        self.__get_content()
        self.__get_xml()
        self.__ocr()
        self.__get_map()

    def __get_content(self):
        """
        根据 url 下载  woff 文件
        """
        resp = requests.get(self.font_url)
        if not resp.status_code == 200:
            # todo: try 异常
            raise Exception('网络请求失败')
        with open(f'./cache/{self.file_name}.woff', mode='wb') as f:
            f.write(resp.content)

    def __get_xml(self):
        """
        将 woff 文件转化为 xml 文件
        """
        try:
            TTFont(f'./cache/{self.file_name}.woff').saveXML(f'./cache/{self.file_name}.xml')
        except TTLibError as e:
            # todo: try 异常
            raise Exception(f'字体文件有误 | e={e}')

    def __ocr(self):
        """
        对 woff 文件进行 ocr
        """
        self.ocr_result = woff_ocr.anAlySis(fontName=fr'./cache/{self.file_name}.woff',
                                            imagePath='./cache/image').run()

    def __get_map(self):
        """
            设置映射关系
            xml 中：<map code="0xed98" name="uniED98"/><!-- ???? -->
            ocr 结果 中 {'uniED98.png': '9'}

            结果为
            {'0xed98': '9'}
        """
        with open(f'./cache/{self.file_name}.xml') as f:
            xml = f.read()
        mapping = {}
        for k, v in self.ocr_result.items():
            k_name = k.rstrip('.png')
            match = re.search(rf'<map code="0(.*?)" name="{k_name}"/>', xml)
            if match:
                mapping[match.group(1)] = v
        self.mapping = mapping

    def get_text_by_font_code(self, font_code: str) -> str:
        """
            通过代码返回对应的字: &#xe274
        """
        return self.mapping.get(font_code[2:])


class ocr:
    data = {}

    def __init__(self):
        if os.path.exists('cache/data.json'):
            with open('cache/data.json', 'r') as f:
                s = f.read()
                self.data = json.loads(s)
        else:
            self.num = -1
        pass

    def to_ocr(self, url: str):
        start = url.rfind('/') + 1
        end = url.rfind('.')
        FN = url[start:end]
        if not os.path.exists(f'./cache/{FN}'):
            os.makedirs(f'./cache/{FN}')
        filename = FN + '/' + FN
        woff = WoffFontOcrFaFa(url, filename)
        font = TTFont(f'./cache/{filename}.woff')
        key = font.getGlyphOrder()[2:]
        os.remove(f'./cache/{filename}.woff')
        os.remove(f'./cache/{filename}.xml')
        # print(key)
        li = {}
        for code in key:
            code = code.replace('uni', '&#x').lower()
            ts = woff.get_text_by_font_code(code)
            if ts == 'O' or ts == 'o':
                ts = 0
            li[code] = ts
        self.data[FN] = li
        with open('cache/datas2.json', 'w') as f:
            json.dump(self.data, f)
        if os.path.exists('cache/data.json'):
            os.remove('cache/data.json')
        os.renames('cache/datas2.json', 'cache/data.json')

    def get(self, url: str):
        start = url.rfind('/') + 1
        end = url.rfind('.')
        FN = url[start:end]
        if self.data.keys().__contains__(FN):
            return self.data.get(FN)
        else:
            self.to_ocr(url)
            return self.data.get(FN, {})
